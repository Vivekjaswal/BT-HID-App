//
//  HIDappApp.swift
//  HIDapp
//
//
//  Created by Jesus Macbook on 18/10/24.
//

import SwiftUI

@main
struct HIDControllerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

